package com.axis.team4.codecrafters.chatwaveeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatwaveEurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
