package com.axis.team4.codecrafters.chatwave.api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatwaveApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
