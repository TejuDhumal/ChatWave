package com.axis.team4.codecrafters.chatwave.chathistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatwaveChathistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
